# PoultryDetectAdvanced

A poultry disease detection and management web application.
